class foo:
    print("test")